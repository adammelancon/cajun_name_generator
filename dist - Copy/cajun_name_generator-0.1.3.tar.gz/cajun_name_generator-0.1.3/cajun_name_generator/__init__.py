"""Top-level package for Cajun Name Generator."""

__author__ = """Adam Melancon"""
__email__ = 'adammelancon@gmail.com'
__version__ = '0.1.3'

