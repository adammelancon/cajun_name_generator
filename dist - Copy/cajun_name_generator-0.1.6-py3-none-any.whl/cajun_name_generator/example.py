from cajun_name_generator import Cajunnames

cng = Cajunnames()

cng.random_first_name(3)
cng.random_last_name(3)
cng.random_full_name(3)

