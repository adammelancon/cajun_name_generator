"""Top-level package for Cajun Name Generator."""

__author__ = """Adam Melancon"""
__email__ = 'adammelancon@gmail.com'
__version__ = '0.1.0'

from cajun_name_generator import CajunNames
from cajunnamelist import firstnames, lastnames
